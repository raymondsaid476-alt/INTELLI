"""
validation_interface.py — Data Validation Pipeline for SYMBIOTE-OS v3.0
Schema validation, quality scoring, and cross-source consistency checking.
"""

import logging
import hashlib
from datetime import datetime, timezone
from dataclasses import dataclass, field

import jsonschema

logger = logging.getLogger(__name__)

# ─── Schemas ─────────────────────────────────────────────────────────────────

INSIGHT_SCHEMA = {
    "type": "object",
    "required": ["id", "title", "summary", "confidence", "source", "tags"],
    "properties": {
        "id":         {"type": "string", "minLength": 1},
        "title":      {"type": "string", "minLength": 3, "maxLength": 300},
        "summary":    {"type": "string", "minLength": 10},
        "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0},
        "source":     {"type": "string"},
        "tags":       {"type": "array", "items": {"type": "string"}},
        "date":       {"type": "string"},
    },
    "additionalProperties": True,
}

ENTITY_SCHEMA = {
    "type": "object",
    "required": ["id", "name", "entity_type"],
    "properties": {
        "id":          {"type": "string"},
        "name":        {"type": "string", "minLength": 1},
        "entity_type": {"type": "string",
                        "enum": ["Country", "Organization", "Person",
                                 "Commodity", "Technology", "Region"]},
    },
}


@dataclass
class ValidationResult:
    is_valid:       bool
    quality_score:  float          # [0, 1]
    errors:         list[str] = field(default_factory=list)
    warnings:       list[str] = field(default_factory=list)
    data_hash:      str = ""
    validated_at:   str = ""

    def __post_init__(self):
        if not self.validated_at:
            self.validated_at = datetime.now(timezone.utc).isoformat()


def validate_insight(data: dict) -> ValidationResult:
    errors, warnings = [], []

    try:
        jsonschema.validate(instance=data, schema=INSIGHT_SCHEMA)
    except jsonschema.ValidationError as e:
        errors.append(f"Schema: {e.message}")

    confidence = data.get("confidence", 0)
    if confidence < 0.5:
        warnings.append(f"Low confidence ({confidence:.2f}) — may not be surfaced")

    summary = data.get("summary", "")
    if len(summary) < 50:
        warnings.append("Summary is very short; consider expanding")

    # Quality score: starts at 1.0, deducted per issue
    score = 1.0 - (len(errors) * 0.4) - (len(warnings) * 0.1)
    score = max(0.0, min(1.0, score))

    return ValidationResult(
        is_valid      = len(errors) == 0,
        quality_score = score,
        errors        = errors,
        warnings      = warnings,
        data_hash     = hashlib.sha256(str(data).encode()).hexdigest()[:16],
    )


def validate_entity(data: dict) -> ValidationResult:
    errors, warnings = [], []
    try:
        jsonschema.validate(instance=data, schema=ENTITY_SCHEMA)
    except jsonschema.ValidationError as e:
        errors.append(f"Schema: {e.message}")

    if not data.get("name", "").strip():
        errors.append("Entity name is blank")

    score = 1.0 - (len(errors) * 0.5) - (len(warnings) * 0.1)
    return ValidationResult(
        is_valid=len(errors) == 0,
        quality_score=max(0.0, score),
        errors=errors,
        warnings=warnings,
        data_hash=hashlib.sha256(str(data).encode()).hexdigest()[:16],
    )


def validate_batch(items: list[dict], item_type: str = "insight") -> dict:
    validator  = validate_insight if item_type == "insight" else validate_entity
    results    = [validator(item) for item in items]
    valid_n    = sum(1 for r in results if r.is_valid)
    avg_qual   = sum(r.quality_score for r in results) / max(len(results), 1)
    return {
        "total":           len(results),
        "valid":           valid_n,
        "invalid":         len(results) - valid_n,
        "avg_quality":     round(avg_qual, 3),
        "pass_rate":       round(valid_n / max(len(results), 1), 3),
        "invalid_indices": [i for i, r in enumerate(results) if not r.is_valid],
    }
