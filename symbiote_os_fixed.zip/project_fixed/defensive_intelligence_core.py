"""
defensive_intelligence_core.py — Security & Quality Defense for SYMBIOTE-OS v3.0
Data poisoning detection, anomaly detection, and model drift monitoring.
"""

import os
import logging
import hashlib
import statistics
from datetime import datetime, timezone
from dataclasses import dataclass
from collections import deque

logger = logging.getLogger(__name__)

REDIS_URL        = os.getenv("REDIS_URL", "redis://redis:6379/0")
DRIFT_WINDOW     = int(os.getenv("DRIFT_WINDOW", "500"))       # last N predictions
ANOMALY_SIGMA    = float(os.getenv("ANOMALY_SIGMA", "3.0"))    # z-score threshold
POISON_MIN_ITEMS = int(os.getenv("POISON_MIN_ITEMS", "5"))


@dataclass
class ThreatAssessment:
    threat_detected:   bool
    threat_type:       str              # "poisoning" | "drift" | "anomaly" | "clean"
    severity:          str              # "low" | "medium" | "high" | "critical"
    details:           str
    recommended_action: str
    assessed_at:       str = ""

    def __post_init__(self):
        if not self.assessed_at:
            self.assessed_at = datetime.now(timezone.utc).isoformat()


# ─── Sliding window tracker (in-memory + Redis-backed) ───────────────────────

_confidence_window: deque = deque(maxlen=DRIFT_WINDOW)
_label_window:      deque = deque(maxlen=DRIFT_WINDOW)


def record_prediction(confidence: float, label: str) -> None:
    _confidence_window.append(confidence)
    _label_window.append(label)


# ─── Data Poisoning Detection ─────────────────────────────────────────────────

def detect_poisoning(items: list[dict]) -> ThreatAssessment:
    """
    Heuristic detection of potential data poisoning in a batch of items.
    Checks for: duplicate hashes, extreme confidence clustering,
    unusual source concentration, and payload injection patterns.
    """
    if len(items) < POISON_MIN_ITEMS:
        return ThreatAssessment(False, "clean", "low",
                                "Batch too small for poisoning analysis",
                                "continue")

    hashes  = [hashlib.sha256(str(i).encode()).hexdigest() for i in items]
    uniq_r  = len(set(hashes)) / len(hashes)

    confs   = [i.get("confidence", 0.5) for i in items if "confidence" in i]
    conf_std = statistics.stdev(confs) if len(confs) > 1 else 1.0

    sources = [i.get("source", "") for i in items]
    src_conc = max(sources.count(s) for s in set(sources)) / len(sources) if sources else 0

    # Injection pattern scan (basic)
    injection_triggers = ["<script", "{{", "${", "DROP TABLE", "UNION SELECT"]
    text_blobs = " ".join(str(v) for i in items for v in i.values())
    has_injection = any(t.lower() in text_blobs.lower() for t in injection_triggers)

    if has_injection:
        return ThreatAssessment(True, "poisoning", "critical",
                                "Injection pattern detected in batch",
                                "quarantine_and_alert")
    if uniq_r < 0.6:
        return ThreatAssessment(True, "poisoning", "high",
                                f"Duplicate rate {1-uniq_r:.0%} exceeds threshold",
                                "deduplicate_and_review")
    if conf_std < 0.02 and len(confs) > 10:
        return ThreatAssessment(True, "poisoning", "medium",
                                "Suspiciously uniform confidence scores",
                                "flag_for_review")
    if src_conc > 0.9:
        return ThreatAssessment(True, "poisoning", "medium",
                                f"Single source dominates batch ({src_conc:.0%})",
                                "diversify_sources")

    return ThreatAssessment(False, "clean", "low", "No poisoning signals detected", "continue")


# ─── Model Drift Detection ────────────────────────────────────────────────────

def detect_model_drift() -> ThreatAssessment:
    """
    Detects distribution shift in model predictions over the sliding window.
    Compares recent 20% of window vs historical 80%.
    """
    if len(_confidence_window) < 50:
        return ThreatAssessment(False, "clean", "low",
                                f"Insufficient data ({len(_confidence_window)} samples)",
                                "continue")

    confs    = list(_confidence_window)
    split    = max(10, len(confs) // 5)
    recent   = confs[-split:]
    historic = confs[:-split]

    recent_mean   = statistics.mean(recent)
    historic_mean = statistics.mean(historic)
    historic_std  = statistics.stdev(historic) if len(historic) > 1 else 0.01

    delta = abs(recent_mean - historic_mean)
    z     = delta / (historic_std + 1e-9)

    if z > ANOMALY_SIGMA * 2:
        return ThreatAssessment(True, "drift", "high",
                                f"Confidence drift z={z:.2f} (Δ={delta:.3f})",
                                "retrain_or_recalibrate")
    if z > ANOMALY_SIGMA:
        return ThreatAssessment(True, "drift", "medium",
                                f"Mild drift z={z:.2f}",
                                "monitor_closely")

    labels    = list(_label_window)
    l_recent  = labels[-split:]
    neg_rate  = l_recent.count("NEGATIVE") / max(len(l_recent), 1)
    if neg_rate > 0.85:
        return ThreatAssessment(True, "drift", "medium",
                                f"Negative label concentration {neg_rate:.0%}",
                                "review_data_sources")

    return ThreatAssessment(False, "clean", "low",
                            f"No drift detected (z={z:.2f})", "continue")


# ─── Anomaly Detection ────────────────────────────────────────────────────────

def detect_anomaly(value: float, metric_name: str,
                   history: list[float]) -> ThreatAssessment:
    """
    Z-score anomaly detection for arbitrary numeric metrics
    (latency, error rate, revenue, etc.).
    """
    if len(history) < 10:
        return ThreatAssessment(False, "clean", "low",
                                "Insufficient history", "continue")
    mean = statistics.mean(history)
    std  = statistics.stdev(history) if len(history) > 1 else 1e-9
    z    = abs(value - mean) / (std + 1e-9)

    if z > ANOMALY_SIGMA * 2:
        return ThreatAssessment(True, "anomaly", "high",
                                f"{metric_name}={value:.3f} is {z:.1f}σ from mean {mean:.3f}",
                                "alert_and_investigate")
    if z > ANOMALY_SIGMA:
        return ThreatAssessment(True, "anomaly", "medium",
                                f"{metric_name}={value:.3f} is {z:.1f}σ from mean",
                                "log_and_monitor")
    return ThreatAssessment(False, "clean", "low",
                            f"{metric_name} within normal range (z={z:.2f})", "continue")


# ─── Full Defense Scan ────────────────────────────────────────────────────────

def run_full_defense_scan(batch: list[dict],
                           recent_metrics: dict | None = None) -> dict:
    """
    Runs all defensive checks and returns a consolidated report.
    """
    poison_result = detect_poisoning(batch)
    drift_result  = detect_model_drift()

    threats = [r for r in [poison_result, drift_result] if r.threat_detected]
    severity_rank = {"critical": 4, "high": 3, "medium": 2, "low": 1}
    worst = max(threats, key=lambda t: severity_rank.get(t.severity, 0)) if threats else None

    return {
        "threats_detected": len(threats),
        "worst_severity":   worst.severity if worst else "none",
        "poisoning":        vars(poison_result),
        "drift":            vars(drift_result),
        "recommendation":   worst.recommended_action if worst else "continue",
        "scanned_at":       datetime.now(timezone.utc).isoformat(),
    }
