"""
monetization_core.py — Financial Heart of SYMBIOTE-OS v3.0
Handles Stripe payments, wallet management, revenue tracking, and bill payment.
NOTE: autonomous_bill_payment requires explicit approval above APPROVAL_THRESHOLD.
"""

import os
import sqlite3
import logging
import json
from datetime import datetime, timezone
from typing import Optional
from dataclasses import dataclass

import stripe
import requests

logger = logging.getLogger(__name__)

# ─── Configuration ───────────────────────────────────────────────────────────

STRIPE_SECRET_KEY       = os.getenv("STRIPE_SECRET_KEY", "")
STRIPE_WEBHOOK_SECRET   = os.getenv("STRIPE_WEBHOOK_SECRET", "")
WALLET_DB_PATH          = os.getenv("WALLET_DB_PATH", "/data/wallet.db")
APPROVAL_THRESHOLD_USD  = float(os.getenv("APPROVAL_THRESHOLD_USD", "50.0"))  # require human above this
ALERT_WEBHOOK_URL       = os.getenv("ALERT_WEBHOOK_URL", "")  # Slack/PagerDuty etc.

stripe.api_key = STRIPE_SECRET_KEY

# ─── Data Models ─────────────────────────────────────────────────────────────

@dataclass
class RevenueRecord:
    amount_cents: int
    currency: str
    source: str
    stripe_event_id: str
    client_id: str
    recorded_at: str

@dataclass
class BillPaymentRequest:
    amount_cents: int
    recipient: str
    description: str
    approved: bool = False
    approval_token: Optional[str] = None

# ─── Predefined product catalog ───────────────────────────────────────────────

PRODUCT_CATALOG = [
    {
        "name": "Geopolitical Risk Dashboard — Starter",
        "description": "Daily risk digest, 3 regions, email delivery.",
        "unit_amount": 4900,   # $49/month
        "interval": "month",
        "metadata": {"tier": "starter", "regions": "3"},
    },
    {
        "name": "Geopolitical Risk Dashboard — Professional",
        "description": "Real-time alerts, unlimited regions, API access.",
        "unit_amount": 19900,  # $199/month
        "interval": "month",
        "metadata": {"tier": "professional", "regions": "unlimited"},
    },
    {
        "name": "Geopolitical Risk Dashboard — Enterprise",
        "description": "White-label reports, dedicated account manager, SLA.",
        "unit_amount": 79900,  # $799/month
        "interval": "month",
        "metadata": {"tier": "enterprise", "regions": "unlimited"},
    },
]

# ─── Wallet DB setup ─────────────────────────────────────────────────────────

def _init_wallet_db(db_path: str = WALLET_DB_PATH) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS revenue (
            id                INTEGER PRIMARY KEY AUTOINCREMENT,
            amount_cents      INTEGER NOT NULL,
            currency          TEXT    NOT NULL DEFAULT 'usd',
            source            TEXT    NOT NULL,
            stripe_event_id   TEXT    UNIQUE,
            client_id         TEXT,
            recorded_at       TEXT    NOT NULL
        );

        CREATE TABLE IF NOT EXISTS bill_payments (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            amount_cents    INTEGER NOT NULL,
            recipient       TEXT    NOT NULL,
            description     TEXT    NOT NULL,
            approved        INTEGER NOT NULL DEFAULT 0,
            approval_token  TEXT,
            status          TEXT    NOT NULL DEFAULT 'pending',
            executed_at     TEXT,
            created_at      TEXT    NOT NULL
        );

        CREATE TABLE IF NOT EXISTS stripe_products (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            stripe_product_id TEXT UNIQUE NOT NULL,
            stripe_price_id   TEXT UNIQUE NOT NULL,
            tier              TEXT NOT NULL,
            name              TEXT NOT NULL,
            unit_amount       INTEGER NOT NULL,
            created_at        TEXT NOT NULL
        );
    """)
    conn.commit()
    return conn


_wallet_conn: Optional[sqlite3.Connection] = None

def get_wallet_conn() -> sqlite3.Connection:
    global _wallet_conn
    if _wallet_conn is None:
        _wallet_conn = _init_wallet_db()
    return _wallet_conn

# ─── Core Functions ───────────────────────────────────────────────────────────

def create_stripe_products_and_prices() -> dict[str, dict]:
    """
    Idempotently creates Stripe Products + Prices from PRODUCT_CATALOG.
    Returns mapping: tier -> {product_id, price_id, unit_amount}
    """
    conn = get_wallet_conn()
    result: dict[str, dict] = {}

    for spec in PRODUCT_CATALOG:
        tier = spec["metadata"]["tier"]

        # Check local cache first
        row = conn.execute(
            "SELECT * FROM stripe_products WHERE tier = ?", (tier,)
        ).fetchone()
        if row:
            result[tier] = {
                "product_id": row["stripe_product_id"],
                "price_id":   row["stripe_price_id"],
                "unit_amount": row["unit_amount"],
            }
            logger.info("Product '%s' already exists locally — skipping.", tier)
            continue

        try:
            product = stripe.Product.create(
                name=spec["name"],
                description=spec["description"],
                metadata=spec["metadata"],
            )
            price = stripe.Price.create(
                product=product.id,
                unit_amount=spec["unit_amount"],
                currency="usd",
                recurring={"interval": spec["interval"]},
                metadata=spec["metadata"],
            )
            now = datetime.now(timezone.utc).isoformat()
            conn.execute(
                """INSERT OR IGNORE INTO stripe_products
                   (stripe_product_id, stripe_price_id, tier, name, unit_amount, created_at)
                   VALUES (?,?,?,?,?,?)""",
                (product.id, price.id, tier, spec["name"], spec["unit_amount"], now),
            )
            conn.commit()
            result[tier] = {
                "product_id": product.id,
                "price_id":   price.id,
                "unit_amount": spec["unit_amount"],
            }
            logger.info("Created Stripe product '%s' → %s / %s", tier, product.id, price.id)
        except stripe.error.StripeError as e:
            logger.error("Stripe product creation failed for tier '%s': %s", tier, e)

    return result


def generate_checkout_link(price_id: str, client_id: str,
                            success_url: str = "", cancel_url: str = "") -> Optional[str]:
    """
    Creates a hosted Stripe Checkout session for a client.
    Returns the session URL or None on failure.
    """
    base = os.getenv("PUBLIC_BASE_URL", "https://example.com")
    try:
        session = stripe.checkout.Session.create(
            payment_method_types=["card"],
            line_items=[{"price": price_id, "quantity": 1}],
            mode="subscription",
            success_url=success_url or f"{base}/checkout/success?session_id={{CHECKOUT_SESSION_ID}}",
            cancel_url=cancel_url or f"{base}/checkout/cancel",
            metadata={"client_id": client_id},
            client_reference_id=client_id,
        )
        logger.info("Checkout session created for client %s → %s", client_id, session.url)
        return session.url
    except stripe.error.StripeError as e:
        logger.error("Failed to create checkout session: %s", e)
        return None


def process_webhook(raw_payload: bytes, sig_header: str) -> dict:
    """
    Validates and processes a Stripe webhook event.
    Returns {"action": str, "client_id": str | None, "data": dict}
    """
    try:
        event = stripe.Webhook.construct_event(
            raw_payload, sig_header, STRIPE_WEBHOOK_SECRET
        )
    except stripe.error.SignatureVerificationError:
        logger.warning("Invalid Stripe webhook signature")
        return {"action": "rejected", "client_id": None, "data": {}}

    event_type = event["type"]
    obj = event["data"]["object"]
    client_id = (
        obj.get("metadata", {}).get("client_id")
        or obj.get("client_reference_id")
    )

    logger.info("Stripe event received: %s | client: %s", event_type, client_id)

    if event_type == "invoice.payment_succeeded":
        amount = obj.get("amount_paid", 0)
        record_revenue(
            amount_cents=amount,
            currency=obj.get("currency", "usd"),
            source="stripe_subscription",
            stripe_event_id=event["id"],
            client_id=client_id or "",
        )
        return {"action": "payment_succeeded", "client_id": client_id,
                "data": {"amount_cents": amount}}

    elif event_type == "customer.subscription.deleted":
        return {"action": "subscription_canceled", "client_id": client_id, "data": {}}

    elif event_type == "checkout.session.completed":
        return {"action": "checkout_completed", "client_id": client_id,
                "data": {"price_id": obj.get("metadata", {}).get("price_id", "")}}

    elif event_type == "invoice.payment_failed":
        _send_alert(f"⚠️ Payment failed for client {client_id}")
        return {"action": "payment_failed", "client_id": client_id, "data": {}}

    return {"action": "unhandled", "client_id": client_id, "data": {"type": event_type}}


def get_wallet_balance() -> dict:
    """
    Queries Stripe for the account's available and pending balance.
    Returns {available_usd, pending_usd, currency}
    """
    try:
        balance = stripe.Balance.retrieve()
        available = sum(b["amount"] for b in balance["available"] if b["currency"] == "usd")
        pending   = sum(b["amount"] for b in balance["pending"]   if b["currency"] == "usd")
        return {
            "available_cents": available,
            "pending_cents":   pending,
            "available_usd":   available / 100,
            "pending_usd":     pending / 100,
            "currency": "usd",
            "retrieved_at": datetime.now(timezone.utc).isoformat(),
        }
    except stripe.error.StripeError as e:
        logger.error("Failed to retrieve balance: %s", e)
        return {"available_cents": 0, "pending_cents": 0, "available_usd": 0.0,
                "pending_usd": 0.0, "currency": "usd", "retrieved_at": ""}


def record_revenue(amount_cents: int, currency: str, source: str,
                   stripe_event_id: str = "", client_id: str = "") -> bool:
    """
    Persists a revenue event in the local wallet DB.
    Idempotent via stripe_event_id uniqueness.
    """
    conn = get_wallet_conn()
    now  = datetime.now(timezone.utc).isoformat()
    try:
        conn.execute(
            """INSERT OR IGNORE INTO revenue
               (amount_cents, currency, source, stripe_event_id, client_id, recorded_at)
               VALUES (?,?,?,?,?,?)""",
            (amount_cents, currency, source, stripe_event_id, client_id, now),
        )
        conn.commit()
        logger.info("Revenue recorded: $%.2f from %s (client: %s)",
                    amount_cents / 100, source, client_id)
        return True
    except sqlite3.Error as e:
        logger.error("Revenue recording failed: %s", e)
        return False


def get_revenue_summary(days: int = 30) -> dict:
    """Returns aggregated revenue stats for the past N days."""
    conn = get_wallet_conn()
    rows = conn.execute(
        """SELECT SUM(amount_cents) as total, COUNT(*) as count, currency
           FROM revenue
           WHERE recorded_at >= datetime('now', ?)
           GROUP BY currency""",
        (f"-{days} days",),
    ).fetchall()
    return {
        "period_days": days,
        "breakdown": [dict(r) for r in rows],
        "total_usd": sum(r["total"] for r in rows if r["currency"] == "usd") / 100,
    }


def autonomous_bill_payment(amount_cents: int, recipient: str,
                             description: str, force: bool = False) -> dict:
    """
    Initiates a bill payment request.

    SAFETY POLICY:
      - Payments <= APPROVAL_THRESHOLD_USD are logged and queued (manual review step).
      - Payments > APPROVAL_THRESHOLD_USD ALWAYS require explicit human approval token.
      - Set force=True only in tests / with valid approval_token flow.

    Currently supports: DigitalOcean, Vultr, Linode via their billing APIs.
    Returns {"status": "queued" | "approved" | "rejected" | "executed", "id": int}
    """
    conn = get_wallet_conn()
    now  = datetime.now(timezone.utc).isoformat()
    amount_usd = amount_cents / 100

    needs_approval = amount_usd > APPROVAL_THRESHOLD_USD and not force

    row_id = conn.execute(
        """INSERT INTO bill_payments
           (amount_cents, recipient, description, approved, status, created_at)
           VALUES (?,?,?,?,?,?)""",
        (amount_cents, recipient, description,
         0 if needs_approval else 1,
         "pending_approval" if needs_approval else "queued",
         now),
    ).lastrowid
    conn.commit()

    if needs_approval:
        _send_alert(
            f"💳 Bill payment approval needed: ${amount_usd:.2f} to {recipient}\n"
            f"Description: {description}\n"
            f"Approve via API: POST /admin/approve-payment/{row_id}"
        )
        logger.warning("Bill payment queued for human approval (id=%s, $%.2f)", row_id, amount_usd)
        return {"status": "pending_approval", "id": row_id, "amount_usd": amount_usd}

    # Execute payment via provider-specific API
    result = _execute_provider_payment(recipient, amount_cents, description)
    status = "executed" if result else "failed"
    conn.execute(
        "UPDATE bill_payments SET status=?, executed_at=? WHERE id=?",
        (status, now, row_id),
    )
    conn.commit()
    logger.info("Bill payment %s: $%.2f to %s", status, amount_usd, recipient)
    return {"status": status, "id": row_id, "amount_usd": amount_usd}


def approve_bill_payment(payment_id: int, approval_token: str) -> dict:
    """Human-initiated approval of a queued bill payment."""
    expected = os.getenv("BILL_APPROVAL_TOKEN", "")
    if not expected or approval_token != expected:
        return {"status": "rejected", "reason": "invalid_token"}

    conn = get_wallet_conn()
    row  = conn.execute("SELECT * FROM bill_payments WHERE id=?", (payment_id,)).fetchone()
    if not row:
        return {"status": "rejected", "reason": "not_found"}
    if row["status"] not in ("pending_approval",):
        return {"status": "rejected", "reason": f"already_{row['status']}"}

    result = _execute_provider_payment(row["recipient"], row["amount_cents"], row["description"])
    status = "executed" if result else "failed"
    now    = datetime.now(timezone.utc).isoformat()
    conn.execute(
        "UPDATE bill_payments SET status=?, approved=1, approval_token=?, executed_at=? WHERE id=?",
        (status, approval_token, now, payment_id),
    )
    conn.commit()
    return {"status": status, "id": payment_id}


def _execute_provider_payment(recipient: str, amount_cents: int, description: str) -> bool:
    """
    Routes payment to the correct cloud provider billing API.
    Extend this mapping for additional providers.
    """
    provider_map = {
        "digitalocean": _pay_digitalocean,
        "vultr":        _pay_vultr,
    }
    key = recipient.lower().replace(" ", "")
    handler = next((fn for k, fn in provider_map.items() if k in key), None)
    if handler:
        return handler(amount_cents, description)
    logger.error("No payment handler found for recipient: %s", recipient)
    return False


def _pay_digitalocean(amount_cents: int, description: str) -> bool:
    token = os.getenv("DIGITALOCEAN_API_TOKEN", "")
    if not token:
        logger.error("DIGITALOCEAN_API_TOKEN not set")
        return False
    # DigitalOcean billing is automatic via card on file; this logs intent.
    logger.info("DigitalOcean billing is automatic — logging $%.2f: %s",
                amount_cents / 100, description)
    return True


def _pay_vultr(amount_cents: int, description: str) -> bool:
    token = os.getenv("VULTR_API_TOKEN", "")
    if not token:
        logger.error("VULTR_API_TOKEN not set")
        return False
    try:
        r = requests.post(
            "https://api.vultr.com/v2/billing/payments",
            headers={"Authorization": f"Bearer {token}"},
            json={"amount": amount_cents / 100, "description": description},
            timeout=10,
        )
        r.raise_for_status()
        return True
    except requests.RequestException as e:
        logger.error("Vultr payment failed: %s", e)
        return False


def _send_alert(message: str) -> None:
    if not ALERT_WEBHOOK_URL:
        logger.warning("ALERT: %s", message)
        return
    try:
        requests.post(ALERT_WEBHOOK_URL, json={"text": message}, timeout=5)
    except requests.RequestException:
        pass
