"""
sentiment_engine.py — Async Multi-Source Sentiment Analysis for SYMBIOTE-OS v3.0
Aggregates sentiment across sources with confidence weighting and uncertainty estimation.
"""

import os
import asyncio
import logging
import hashlib
import json
from datetime import datetime, timezone
from dataclasses import dataclass, field
from typing import Optional

import aiohttp
import redis.asyncio as aioredis
from transformers import pipeline, Pipeline

logger = logging.getLogger(__name__)

# ─── Config ───────────────────────────────────────────────────────────────────

REDIS_URL          = os.getenv("REDIS_URL", "redis://redis:6379/0")
SENTIMENT_MODEL    = os.getenv("SENTIMENT_MODEL", "ProsusAI/finbert")
GDELT_API_BASE     = os.getenv("GDELT_API_BASE", "https://api.gdeltproject.org/api/v2")
NEWSAPI_KEY        = os.getenv("NEWSAPI_KEY", "")
CACHE_TTL_SECONDS  = int(os.getenv("SENTIMENT_CACHE_TTL", "3600"))

# Source reliability weights (sum needn't equal 1; normalised internally)
SOURCE_WEIGHTS = {
    "gdelt":    0.6,
    "newsapi":  0.5,
    "rss":      0.4,
    "internal": 1.0,
}

# ─── Data Models ─────────────────────────────────────────────────────────────

@dataclass
class SentimentResult:
    text_hash:      str
    label:          str          # POSITIVE | NEGATIVE | NEUTRAL
    score:          float        # model confidence [0,1]
    uncertainty:    float        # epistemic uncertainty estimate
    source:         str
    entity_refs:    list[str] = field(default_factory=list)
    analysed_at:    str        = ""

    def __post_init__(self):
        if not self.analysed_at:
            self.analysed_at = datetime.now(timezone.utc).isoformat()


@dataclass
class AggregatedSentiment:
    topic:              str
    weighted_score:     float          # [-1, +1] valence
    dominant_label:     str
    confidence:         float          # aggregate confidence
    uncertainty:        float
    source_count:       int
    results:            list[SentimentResult] = field(default_factory=list)
    computed_at:        str = ""

    def __post_init__(self):
        if not self.computed_at:
            self.computed_at = datetime.now(timezone.utc).isoformat()

    def to_insight(self, title: str = "") -> dict:
        return {
            "title":      title or f"Sentiment: {self.topic}",
            "summary":    (
                f"{self.dominant_label.title()} sentiment on '{self.topic}' "
                f"(score: {self.weighted_score:+.2f}, "
                f"confidence: {self.confidence:.0%}, "
                f"sources: {self.source_count})"
            ),
            "confidence": self.confidence,
            "tags":       [self.topic, "sentiment", self.dominant_label.lower()],
        }

# ─── Model Loading ────────────────────────────────────────────────────────────

_sentiment_pipeline: Optional[Pipeline] = None

def get_sentiment_pipeline() -> Pipeline:
    global _sentiment_pipeline
    if _sentiment_pipeline is None:
        logger.info("Loading sentiment model: %s", SENTIMENT_MODEL)
        _sentiment_pipeline = pipeline(
            "text-classification",
            model=SENTIMENT_MODEL,
            device=-1,  # CPU; set to 0 for GPU
            top_k=None,
        )
        logger.info("Sentiment model loaded.")
    return _sentiment_pipeline

# ─── Core Analysis ────────────────────────────────────────────────────────────

def _analyse_text(text: str, source: str,
                  entity_refs: Optional[list] = None) -> SentimentResult:
    """Runs a single text through the model and wraps the output."""
    pipe    = get_sentiment_pipeline()
    text    = text[:512]  # token limit
    results = pipe(text)[0]           # list of {label, score}

    # Build label→score map
    label_scores = {r["label"].upper(): r["score"] for r in results}
    dominant     = max(label_scores, key=label_scores.get)
    score        = label_scores[dominant]

    # Simple uncertainty: entropy of distribution
    import math
    probs       = list(label_scores.values())
    entropy     = -sum(p * math.log(p + 1e-9) for p in probs)
    max_entropy = math.log(len(probs))
    uncertainty = entropy / max_entropy if max_entropy > 0 else 0.0

    return SentimentResult(
        text_hash   = hashlib.sha256(text.encode()).hexdigest()[:16],
        label       = dominant,
        score       = score,
        uncertainty = uncertainty,
        source      = source,
        entity_refs = entity_refs or [],
    )


async def analyse_text_async(text: str, source: str,
                              entity_refs: Optional[list] = None) -> SentimentResult:
    """Async wrapper — offloads CPU-bound inference to executor."""
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(
        None, _analyse_text, text, source, entity_refs or []
    )


# ─── Data Source Fetchers ─────────────────────────────────────────────────────

async def _fetch_gdelt_articles(topic: str, session: aiohttp.ClientSession) -> list[str]:
    """Fetches recent article summaries from GDELT."""
    params = {
        "query": topic,
        "mode":  "ArtList",
        "maxrecords": "25",
        "format": "json",
        "timespan": "24h",
    }
    try:
        async with session.get(
            f"{GDELT_API_BASE}/doc/doc",
            params=params, timeout=aiohttp.ClientTimeout(total=10)
        ) as resp:
            if resp.status != 200:
                return []
            data     = await resp.json(content_type=None)
            articles = data.get("articles", [])
            return [
                f"{a.get('title', '')}. {a.get('seendescription', '')}"
                for a in articles[:20]
                if a.get("title")
            ]
    except Exception as e:
        logger.warning("GDELT fetch failed for '%s': %s", topic, e)
        return []


async def _fetch_newsapi_articles(topic: str, session: aiohttp.ClientSession) -> list[str]:
    """Fetches headlines from NewsAPI."""
    if not NEWSAPI_KEY:
        return []
    params = {
        "q":        topic,
        "language": "en",
        "pageSize": "20",
        "sortBy":   "publishedAt",
        "apiKey":   NEWSAPI_KEY,
    }
    try:
        async with session.get(
            "https://newsapi.org/v2/everything",
            params=params, timeout=aiohttp.ClientTimeout(total=10)
        ) as resp:
            if resp.status != 200:
                return []
            data     = await resp.json()
            articles = data.get("articles", [])
            return [
                f"{a.get('title', '')}. {a.get('description', '')}"
                for a in articles if a.get("title")
            ]
    except Exception as e:
        logger.warning("NewsAPI fetch failed for '%s': %s", topic, e)
        return []

# ─── Aggregation ─────────────────────────────────────────────────────────────

async def aggregate_topic_sentiment(topic: str,
                                    custom_texts: Optional[list[str]] = None,
                                    use_cache: bool = True) -> AggregatedSentiment:
    """
    Main entry point. Fetches articles from all sources, runs inference,
    then returns a confidence-weighted aggregate sentiment.
    """
    # Check Redis cache
    redis = await aioredis.from_url(REDIS_URL, decode_responses=True)
    cache_key = f"sentiment:{hashlib.md5(topic.encode()).hexdigest()}"

    if use_cache:
        cached = await redis.get(cache_key)
        if cached:
            logger.debug("Cache hit for sentiment topic '%s'", topic)
            d = json.loads(cached)
            return AggregatedSentiment(**d)

    # Fetch from sources in parallel
    async with aiohttp.ClientSession() as session:
        gdelt_task   = _fetch_gdelt_articles(topic, session)
        newsapi_task = _fetch_newsapi_articles(topic, session)
        gdelt_texts, newsapi_texts = await asyncio.gather(gdelt_task, newsapi_task)

    source_batches: dict[str, list[str]] = {
        "gdelt":    gdelt_texts,
        "newsapi":  newsapi_texts,
    }
    if custom_texts:
        source_batches["internal"] = custom_texts

    # Analyse all texts
    all_tasks = []
    for src, texts in source_batches.items():
        for txt in texts:
            if txt.strip():
                all_tasks.append(analyse_text_async(txt, src))

    if not all_tasks:
        return AggregatedSentiment(
            topic=topic, weighted_score=0.0, dominant_label="NEUTRAL",
            confidence=0.0, uncertainty=1.0, source_count=0,
        )

    all_results: list[SentimentResult] = await asyncio.gather(*all_tasks)

    # Weighted aggregation
    label_to_valence = {"POSITIVE": 1.0, "NEGATIVE": -1.0, "NEUTRAL": 0.0}
    total_weight = 0.0
    weighted_valence = 0.0
    weighted_confidence = 0.0
    weighted_uncertainty = 0.0

    for r in all_results:
        w = SOURCE_WEIGHTS.get(r.source, 0.5) * r.score
        v = label_to_valence.get(r.label, 0.0)
        weighted_valence     += w * v
        weighted_confidence  += w * r.score
        weighted_uncertainty += w * r.uncertainty
        total_weight         += w

    if total_weight == 0:
        agg_valence = weighted_uncertainty_agg = 0.0
        agg_confidence = 0.0
    else:
        agg_valence      = weighted_valence     / total_weight
        agg_confidence   = weighted_confidence  / total_weight
        weighted_uncertainty_agg = weighted_uncertainty / total_weight

    dominant = (
        "POSITIVE" if agg_valence > 0.1
        else "NEGATIVE" if agg_valence < -0.1
        else "NEUTRAL"
    )

    agg = AggregatedSentiment(
        topic           = topic,
        weighted_score  = round(agg_valence, 4),
        dominant_label  = dominant,
        confidence      = round(agg_confidence, 4),
        uncertainty     = round(weighted_uncertainty_agg, 4),
        source_count    = len({r.source for r in all_results}),
        results         = all_results,
    )

    # Cache result (exclude full results list for storage efficiency)
    cache_data = {
        "topic": agg.topic, "weighted_score": agg.weighted_score,
        "dominant_label": agg.dominant_label, "confidence": agg.confidence,
        "uncertainty": agg.uncertainty, "source_count": agg.source_count,
        "results": [], "computed_at": agg.computed_at,
    }
    await redis.setex(cache_key, CACHE_TTL_SECONDS, json.dumps(cache_data))
    await redis.aclose()

    logger.info(
        "Sentiment for '%s': %s (score=%.3f, conf=%.2f, n=%d)",
        topic, dominant, agg_valence, agg_confidence, len(all_results),
    )
    return agg
