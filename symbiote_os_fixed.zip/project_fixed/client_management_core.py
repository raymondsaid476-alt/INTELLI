"""
client_management_core.py — Client Lifecycle Management for SYMBIOTE-OS v3.0
Handles creation, access control, usage tracking, and automated report generation.
"""

import os
import secrets
import logging
from datetime import datetime, timezone
from typing import Optional
from enum import Enum

import psycopg2
import psycopg2.extras
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
)

logger = logging.getLogger(__name__)

# ─── Config ───────────────────────────────────────────────────────────────────

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://symbiote:secret@postgres:5432/symbiote")
REPORT_OUTPUT_DIR = os.getenv("REPORT_OUTPUT_DIR", "/data/reports")
SMTP_HOST = os.getenv("SMTP_HOST", "")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER", "")
SMTP_PASS = os.getenv("SMTP_PASS", "")
FROM_EMAIL = os.getenv("FROM_EMAIL", "reports@symbiote.ai")

os.makedirs(REPORT_OUTPUT_DIR, exist_ok=True)


class PlanTier(str, Enum):
    STARTER      = "starter"
    PROFESSIONAL = "professional"
    ENTERPRISE   = "enterprise"

PLAN_LIMITS = {
    PlanTier.STARTER:      {"api_calls_per_month": 500,   "regions": 3},
    PlanTier.PROFESSIONAL: {"api_calls_per_month": 10000, "regions": 999},
    PlanTier.ENTERPRISE:   {"api_calls_per_month": 999999,"regions": 999},
}

# ─── DB Connection ────────────────────────────────────────────────────────────

_db_conn: Optional[psycopg2.extensions.connection] = None

def get_db() -> psycopg2.extensions.connection:
    global _db_conn
    if _db_conn is None or _db_conn.closed:
        _db_conn = psycopg2.connect(DATABASE_URL)
        _db_conn.autocommit = False
    return _db_conn


def init_db_schema() -> None:
    """Creates all required tables if they don't exist."""
    conn = get_db()
    with conn.cursor() as cur:
        cur.execute("""
            CREATE TABLE IF NOT EXISTS clients (
                id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                email           TEXT UNIQUE NOT NULL,
                name            TEXT NOT NULL,
                stripe_customer_id TEXT,
                plan_tier       TEXT NOT NULL DEFAULT 'starter',
                api_key         TEXT UNIQUE,
                is_active       BOOLEAN NOT NULL DEFAULT FALSE,
                created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
            );

            CREATE TABLE IF NOT EXISTS subscriptions (
                id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                client_id           UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
                stripe_subscription_id TEXT UNIQUE,
                stripe_price_id     TEXT,
                plan_tier           TEXT NOT NULL,
                status              TEXT NOT NULL DEFAULT 'active',
                current_period_start TIMESTAMPTZ,
                current_period_end   TIMESTAMPTZ,
                canceled_at         TIMESTAMPTZ,
                created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
            );

            CREATE TABLE IF NOT EXISTS access_logs (
                id          BIGSERIAL PRIMARY KEY,
                client_id   UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
                endpoint    TEXT NOT NULL,
                method      TEXT NOT NULL DEFAULT 'GET',
                ip_address  INET,
                status_code INTEGER,
                latency_ms  INTEGER,
                created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
            );

            CREATE TABLE IF NOT EXISTS reports (
                id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                client_id   UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
                report_type TEXT NOT NULL,
                file_path   TEXT,
                delivered   BOOLEAN NOT NULL DEFAULT FALSE,
                created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
            );

            CREATE INDEX IF NOT EXISTS idx_access_logs_client_time
                ON access_logs(client_id, created_at);
            CREATE INDEX IF NOT EXISTS idx_clients_api_key
                ON clients(api_key) WHERE api_key IS NOT NULL;
        """)
    conn.commit()
    logger.info("Database schema initialised.")


# ─── Client CRUD ──────────────────────────────────────────────────────────────

def create_client(email: str, name: str,
                  stripe_customer_id: Optional[str] = None) -> dict:
    """
    Creates a new client record. Returns client dict with generated API key.
    Client starts inactive until payment is confirmed.
    """
    conn = get_db()
    api_key = _generate_api_key()
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        try:
            cur.execute(
                """INSERT INTO clients (email, name, stripe_customer_id, api_key)
                   VALUES (%s, %s, %s, %s)
                   ON CONFLICT (email) DO UPDATE
                       SET stripe_customer_id = EXCLUDED.stripe_customer_id,
                           updated_at = NOW()
                   RETURNING *""",
                (email, name, stripe_customer_id, api_key),
            )
            row = dict(cur.fetchone())
            conn.commit()
            logger.info("Client created/updated: %s (%s)", name, email)
            return row
        except psycopg2.Error as e:
            conn.rollback()
            logger.error("Failed to create client: %s", e)
            raise


def get_client_by_id(client_id: str) -> Optional[dict]:
    conn = get_db()
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute("SELECT * FROM clients WHERE id = %s", (client_id,))
        row = cur.fetchone()
        return dict(row) if row else None


def get_client_by_api_key(api_key: str) -> Optional[dict]:
    conn = get_db()
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute("SELECT * FROM clients WHERE api_key = %s AND is_active = TRUE", (api_key,))
        row = cur.fetchone()
        return dict(row) if row else None


def list_active_clients(tier: Optional[str] = None) -> list[dict]:
    conn = get_db()
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        if tier:
            cur.execute(
                "SELECT * FROM clients WHERE is_active=TRUE AND plan_tier=%s ORDER BY created_at",
                (tier,),
            )
        else:
            cur.execute("SELECT * FROM clients WHERE is_active=TRUE ORDER BY created_at")
        return [dict(r) for r in cur.fetchall()]


# ─── Access Control ───────────────────────────────────────────────────────────

def grant_access(client_id: str, plan_tier: str,
                 stripe_subscription_id: Optional[str] = None,
                 stripe_price_id: Optional[str] = None) -> bool:
    """
    Called after payment confirmation. Activates the client and upserts subscription.
    """
    conn = get_db()
    try:
        with conn.cursor() as cur:
            cur.execute(
                """UPDATE clients
                   SET is_active=TRUE, plan_tier=%s, updated_at=NOW()
                   WHERE id=%s""",
                (plan_tier, client_id),
            )
            if stripe_subscription_id:
                # Only upsert when we have a non-NULL unique key to conflict on
                cur.execute(
                    """INSERT INTO subscriptions
                       (client_id, stripe_subscription_id, stripe_price_id, plan_tier, status)
                       VALUES (%s, %s, %s, %s, 'active')
                       ON CONFLICT (stripe_subscription_id) DO UPDATE
                           SET status='active', plan_tier=EXCLUDED.plan_tier""",
                    (client_id, stripe_subscription_id, stripe_price_id, plan_tier),
                )
            else:
                # No subscription ID yet (e.g. checkout.session.completed before invoice)
                cur.execute(
                    """INSERT INTO subscriptions
                       (client_id, stripe_price_id, plan_tier, status)
                       VALUES (%s, %s, %s, 'active')""",
                    (client_id, stripe_price_id, plan_tier),
                )
        conn.commit()
        logger.info("Access granted: client %s → tier %s", client_id, plan_tier)
        return True
    except psycopg2.Error as e:
        conn.rollback()
        logger.error("grant_access failed: %s", e)
        return False


def revoke_access(client_id: str, stripe_subscription_id: Optional[str] = None) -> bool:
    """
    Called after subscription cancellation or payment failure.
    Deactivates client; preserves data for audit.
    """
    conn = get_db()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE clients SET is_active=FALSE, updated_at=NOW() WHERE id=%s",
                (client_id,),
            )
            if stripe_subscription_id:
                cur.execute(
                    """UPDATE subscriptions SET status='canceled', canceled_at=NOW()
                       WHERE stripe_subscription_id=%s""",
                    (stripe_subscription_id,),
                )
        conn.commit()
        logger.info("Access revoked for client %s", client_id)
        return True
    except psycopg2.Error as e:
        conn.rollback()
        logger.error("revoke_access failed: %s", e)
        return False


def rotate_api_key(client_id: str) -> Optional[str]:
    """Issues a new API key for a client (e.g., after suspected compromise)."""
    new_key = _generate_api_key()
    conn    = get_db()
    with conn.cursor() as cur:
        cur.execute(
            "UPDATE clients SET api_key=%s, updated_at=NOW() WHERE id=%s",
            (new_key, client_id),
        )
    conn.commit()
    return new_key


# ─── Usage Tracking ───────────────────────────────────────────────────────────

def log_api_call(client_id: str, endpoint: str, method: str = "GET",
                 ip_address: str = "", status_code: int = 200,
                 latency_ms: int = 0) -> None:
    conn = get_db()
    with conn.cursor() as cur:
        cur.execute(
            """INSERT INTO access_logs
               (client_id, endpoint, method, ip_address, status_code, latency_ms)
               VALUES (%s, %s, %s, %s, %s, %s)""",
            (client_id, endpoint, method,
             ip_address or None, status_code, latency_ms),
        )
    conn.commit()


def get_client_usage_stats(client_id: str) -> dict:
    """
    Returns API usage stats for the current billing month.
    Also returns whether the client is within their plan limits.
    """
    conn = get_db()
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute(
            """SELECT COUNT(*) as calls_this_month,
                      COUNT(*) FILTER (WHERE status_code >= 400) as errors,
                      AVG(latency_ms) as avg_latency_ms
               FROM access_logs
               WHERE client_id = %s
                 AND created_at >= date_trunc('month', NOW())""",
            (client_id,),
        )
        usage = dict(cur.fetchone())

        cur.execute("SELECT plan_tier FROM clients WHERE id = %s", (client_id,))
        row = cur.fetchone()

    if not row:
        return {"error": "client_not_found"}

    tier   = row["plan_tier"]
    limits = PLAN_LIMITS.get(PlanTier(tier), PLAN_LIMITS[PlanTier.STARTER])
    calls  = usage["calls_this_month"] or 0

    return {
        "client_id":       client_id,
        "plan_tier":       tier,
        "calls_this_month": calls,
        "limit":           limits["api_calls_per_month"],
        "utilization_pct": round(calls / limits["api_calls_per_month"] * 100, 1),
        "within_limit":    calls < limits["api_calls_per_month"],
        "avg_latency_ms":  round(float(usage["avg_latency_ms"] or 0), 1),
        "errors":          usage["errors"] or 0,
    }


def is_within_usage_limit(client_id: str) -> bool:
    stats = get_client_usage_stats(client_id)
    return stats.get("within_limit", False)


# ─── Report Generation ────────────────────────────────────────────────────────

def generate_automated_report(client_id: str,
                               insights: Optional[list] = None,
                               report_type: str = "weekly_digest") -> Optional[str]:
    """
    Compiles insights into a branded PDF report for the client.
    Returns the file path of the generated PDF, or None on failure.
    Uses reportlab for PDF generation.
    """
    client = get_client_by_id(client_id)
    if not client:
        logger.error("Cannot generate report: client %s not found", client_id)
        return None

    insights = insights or _fetch_sample_insights(client["plan_tier"])
    usage    = get_client_usage_stats(client_id)
    ts       = datetime.now(timezone.utc)
    filename = f"{client_id}_{ts.strftime('%Y%m%d_%H%M%S')}_{report_type}.pdf"
    filepath = os.path.join(REPORT_OUTPUT_DIR, filename)

    try:
        _build_pdf_report(filepath, client, insights, usage, ts)
        _record_report(client_id, report_type, filepath)
        logger.info("Report generated: %s", filepath)
        return filepath
    except Exception as e:
        logger.error("Report generation failed for client %s: %s", client_id, e)
        return None


def _build_pdf_report(filepath: str, client: dict, insights: list,
                      usage: dict, ts: datetime) -> None:
    doc    = SimpleDocTemplate(filepath, pagesize=A4,
                               topMargin=2*cm, bottomMargin=2*cm,
                               leftMargin=2.5*cm, rightMargin=2.5*cm)
    styles = getSampleStyleSheet()
    story  = []

    # Header
    title_style = ParagraphStyle("title", parent=styles["Title"],
                                 textColor=colors.HexColor("#1a1a2e"), fontSize=22)
    story.append(Paragraph("SYMBIOTE-OS Intelligence Report", title_style))
    story.append(Paragraph(
        f"Prepared for: <b>{client['name']}</b> | "
        f"Plan: <b>{client['plan_tier'].title()}</b> | "
        f"Generated: {ts.strftime('%Y-%m-%d %H:%M UTC')}",
        styles["Normal"],
    ))
    story.append(HRFlowable(width="100%", thickness=2,
                            color=colors.HexColor("#e94560")))
    story.append(Spacer(1, 0.4*cm))

    # Usage summary
    story.append(Paragraph("📊 API Usage This Month", styles["Heading2"]))
    usage_data = [
        ["Metric", "Value"],
        ["API Calls", f"{usage.get('calls_this_month', 0):,}"],
        ["Limit", f"{usage.get('limit', 0):,}"],
        ["Utilisation", f"{usage.get('utilization_pct', 0):.1f}%"],
        ["Avg Latency", f"{usage.get('avg_latency_ms', 0):.0f} ms"],
    ]
    tbl = Table(usage_data, colWidths=[8*cm, 8*cm])
    tbl.setStyle(TableStyle([
        ("BACKGROUND",  (0, 0), (-1, 0), colors.HexColor("#1a1a2e")),
        ("TEXTCOLOR",   (0, 0), (-1, 0), colors.white),
        ("FONTNAME",    (0, 0), (-1, 0), "Helvetica-Bold"),
        ("GRID",        (0, 0), (-1, -1), 0.5, colors.lightgrey),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f5f5f5")]),
    ]))
    story.append(tbl)
    story.append(Spacer(1, 0.5*cm))

    # Insights
    story.append(Paragraph("🔍 Key Intelligence Insights", styles["Heading2"]))
    for i, insight in enumerate(insights, 1):
        conf   = insight.get("confidence", 0)
        colour = (colors.green if conf >= 0.8
                  else colors.orange if conf >= 0.6
                  else colors.red)
        story.append(Paragraph(
            f"<b>{i}. {insight.get('title', 'Insight')}</b> "
            f"[Confidence: <font color='{colour.hexval()}'>{conf:.0%}</font>]",
            styles["Heading3"],
        ))
        story.append(Paragraph(insight.get("summary", ""), styles["BodyText"]))
        tags = ", ".join(insight.get("tags", []))
        if tags:
            story.append(Paragraph(f"<i>Tags: {tags}</i>", styles["Normal"]))
        story.append(Spacer(1, 0.3*cm))

    # Footer
    story.append(HRFlowable(width="100%", thickness=1, color=colors.lightgrey))
    story.append(Paragraph(
        "This report is confidential and generated autonomously by SYMBIOTE-OS v3.0. "
        "Not financial or legal advice.",
        ParagraphStyle("footer", parent=styles["Normal"],
                       fontSize=8, textColor=colors.grey),
    ))

    doc.build(story)


def _fetch_sample_insights(tier: str) -> list:
    """Returns placeholder insights; in production, fetched from knowledge graph."""
    base = [
        {"title": "Rising Tensions in the Strait of Hormuz",
         "summary": "Shipping lane risk elevated due to naval exercises.",
         "confidence": 0.82, "tags": ["energy", "maritime", "Iran"]},
        {"title": "EU Carbon Border Tax Implementation",
         "summary": "New tariff regime impacts emerging-market exporters.",
         "confidence": 0.75, "tags": ["trade", "EU", "climate"]},
    ]
    if tier in (PlanTier.PROFESSIONAL, PlanTier.ENTERPRISE):
        base.append({
            "title": "AI Chip Export Controls — Supply Chain Impact",
            "summary": "Semiconductor bottleneck affecting cloud capacity in SEA.",
            "confidence": 0.91, "tags": ["tech", "semiconductors", "US-China"],
        })
    return base


def _record_report(client_id: str, report_type: str, filepath: str) -> None:
    conn = get_db()
    with conn.cursor() as cur:
        cur.execute(
            "INSERT INTO reports (client_id, report_type, file_path) VALUES (%s, %s, %s)",
            (client_id, report_type, filepath),
        )
    conn.commit()


# ─── Helpers ─────────────────────────────────────────────────────────────────

def _generate_api_key() -> str:
    """Generates a secure, prefixed API key."""
    return "sym_" + secrets.token_urlsafe(32)
