"""
main_orchestrator.py — Central Orchestrator for SYMBIOTE-OS v3.0
Coordinates all services, routes insights to paying clients, and monitors financial health.
"""

import asyncio
import logging
import os
import json
from datetime import datetime, timezone
from typing import Optional

import redis.asyncio as aioredis

from knowledge_graph_service   import (get_graph_stats, upsert_event)
from sentiment_engine           import aggregate_topic_sentiment
from validation_interface       import validate_insight
from defensive_intelligence_core import run_full_defense_scan, record_prediction
from self_advancement_core      import run_advancement_cycle, record_metric
from monetization_core          import (get_wallet_balance, get_revenue_summary,
                                        _send_alert)
from client_management_core     import (list_active_clients, generate_automated_report)

logger = logging.getLogger(__name__)

# ─── Config ───────────────────────────────────────────────────────────────────

REDIS_URL             = os.getenv("REDIS_URL", "redis://redis:6379/0")
INSIGHT_MIN_CONFIDENCE = float(os.getenv("INSIGHT_MIN_CONFIDENCE", "0.75"))
WALLET_ALERT_THRESHOLD_USD = float(os.getenv("WALLET_ALERT_THRESHOLD_USD", "500.0"))
OPERATIONAL_COST_USD_MONTH = float(os.getenv("OPERATIONAL_COST_USD_MONTH", "150.0"))
TOPICS_TO_MONITOR      = os.getenv(
    "TOPICS_TO_MONITOR",
    "geopolitical risk,energy security,trade policy,cyber threats,supply chain"
).split(",")

# ─── Internal Status Store ───────────────────────────────────────────────────

_status: dict = {
    "started_at":       datetime.now(timezone.utc).isoformat(),
    "cycles_completed": 0,
    "last_cycle_at":    None,
    "last_insight_count": 0,
    "last_client_deliveries": 0,
    "financial":        {},
    "defense":          {},
    "graph_stats":      {},
}


async def _get_redis() -> aioredis.Redis:
    return await aioredis.from_url(REDIS_URL, decode_responses=True)


# ─── Pipeline: Sentiment → Insight ───────────────────────────────────────────

async def run_insight_pipeline(topics: Optional[list[str]] = None) -> list[dict]:
    """
    For each monitored topic: aggregate sentiment, validate, defensively scan,
    then push high-confidence insights to the knowledge graph.
    Returns list of validated high-confidence insights.
    """
    topics = topics or TOPICS_TO_MONITOR
    insights = []

    tasks = [aggregate_topic_sentiment(t.strip()) for t in topics]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    for topic, result in zip(topics, results):
        if isinstance(result, Exception):
            logger.error("Sentiment pipeline error for '%s': %s", topic, result)
            continue

        record_prediction(result.confidence, result.dominant_label)
        record_metric("sentiment_engine", "sentiment_confidence", result.confidence)

        if result.confidence < INSIGHT_MIN_CONFIDENCE:
            logger.debug("Low confidence for '%s' (%.2f) — skipping", topic, result.confidence)
            continue

        insight_payload = {
            "id":         f"ins_{topic[:20].replace(' ','_')}_{int(datetime.now().timestamp())}",
            "title":      f"{result.dominant_label.title()} Sentiment: {topic.title()}",
            "summary":    result.to_insight()["summary"],
            "confidence": result.confidence,
            "source":     "sentiment_aggregator",
            "tags":       [topic, result.dominant_label.lower(), "automated"],
            "date":       datetime.now(timezone.utc).date().isoformat(),
        }

        validation = validate_insight(insight_payload)
        record_metric("validation_interface", "insight_quality", validation.quality_score)

        if not validation.is_valid:
            logger.warning("Insight failed validation: %s", validation.errors)
            continue

        # Push to knowledge graph
        upsert_event(
            event_id   = insight_payload["id"],
            event_type = "SentimentSignal",
            title      = insight_payload["title"],
            date       = insight_payload["date"],
            confidence = insight_payload["confidence"],
            properties = {"summary": insight_payload["summary"],
                          "tags": json.dumps(insight_payload["tags"])},
        )

        insights.append(insight_payload)

    return insights


# ─── Client-Aware Delivery ────────────────────────────────────────────────────

async def deliver_insights_to_clients(insights: list[dict]) -> int:
    """
    Queries active premium clients and generates automated reports
    for each one, embedding the latest insights.
    Returns the number of successful deliveries.
    """
    if not insights:
        return 0

    premium_tiers = ("professional", "enterprise")
    premium_clients = [
        c for c in list_active_clients()
        if c.get("plan_tier") in premium_tiers
    ]

    logger.info("Delivering %d insights to %d premium clients",
                len(insights), len(premium_clients))

    deliveries = 0
    for client in premium_clients:
        try:
            filepath = generate_automated_report(
                client_id   = str(client["id"]),
                insights    = insights,
                report_type = "real_time_digest",
            )
            if filepath:
                redis = await _get_redis()
                await redis.lpush(
                    f"reports:{client['id']}",
                    json.dumps({"path": filepath,
                                "ts": datetime.now(timezone.utc).isoformat()}),
                )
                await redis.aclose()
                deliveries += 1
        except Exception as e:
            logger.error("Delivery failed for client %s: %s", client["id"], e)

    return deliveries


# ─── Financial Health Check ──────────────────────────────────────────────────

def check_financial_health() -> dict:
    """
    Retrieves wallet balance and revenue summary.
    Alerts if balance drops below operational threshold.
    Returns financial status dict.
    """
    balance = get_wallet_balance()
    revenue = get_revenue_summary(days=30)

    available_usd = balance.get("available_usd", 0.0)
    months_runway = available_usd / max(OPERATIONAL_COST_USD_MONTH, 1.0)

    financial_status = {
        "available_usd":        available_usd,
        "pending_usd":          balance.get("pending_usd", 0.0),
        "revenue_30d_usd":      revenue.get("total_usd", 0.0),
        "months_runway":        round(months_runway, 2),
        "operational_cost_usd": OPERATIONAL_COST_USD_MONTH,
        "health":               "healthy",
        "checked_at":           datetime.now(timezone.utc).isoformat(),
    }

    if available_usd < WALLET_ALERT_THRESHOLD_USD:
        financial_status["health"] = "critical"
        _send_alert(
            f"🚨 CRITICAL: Wallet balance ${available_usd:.2f} below threshold "
            f"${WALLET_ALERT_THRESHOLD_USD:.2f}. Runway: {months_runway:.1f} months."
        )
        logger.critical("Wallet below threshold! $%.2f available", available_usd)
    elif months_runway < 2:
        financial_status["health"] = "warning"
        _send_alert(f"⚠️ Low runway: {months_runway:.1f} months of operations funded.")
        logger.warning("Low financial runway: %.1f months", months_runway)

    return financial_status


# ─── Main Orchestration Cycle ────────────────────────────────────────────────

async def run_orchestration_cycle() -> dict:
    """
    One full orchestration cycle:
    1. Defense scan (health check on recent data)
    2. Insight pipeline (sentiment → graph)
    3. Client delivery
    4. Financial monitoring
    5. Self-advancement (weekly cadence via Redis flag)
    Returns cycle summary.
    """
    cycle_start = datetime.now(timezone.utc)
    logger.info("=== Orchestration cycle starting ===")

    redis = await _get_redis()

    # 1. Defense scan (uses in-memory windows, no batch here)
    defense_report = run_full_defense_scan(batch=[])
    _status["defense"] = defense_report

    # 2. Insight pipeline
    insights = await run_insight_pipeline()
    record_metric("orchestrator", "insight_count", len(insights))
    _status["last_insight_count"] = len(insights)

    # 3. Client delivery
    deliveries = await deliver_insights_to_clients(insights)
    _status["last_client_deliveries"] = deliveries

    # 4. Financial health
    financial = check_financial_health()
    _status["financial"] = financial

    # 5. Graph stats
    _status["graph_stats"] = get_graph_stats()

    # 6. Self-advancement (gated: run once per day via Redis flag)
    adv_result = {}
    adv_flag = await redis.get("advancement:last_run_date")
    today_str = cycle_start.date().isoformat()
    if adv_flag != today_str:
        logger.info("Running self-advancement cycle...")
        adv_result = run_advancement_cycle()
        await redis.set("advancement:last_run_date", today_str, ex=86400)
        logger.info("Self-advancement: %s", adv_result.get("status"))

    # Publish status to Redis for Flask app
    _status["cycles_completed"] += 1
    _status["last_cycle_at"] = cycle_start.isoformat()
    await redis.set("orchestrator:status", json.dumps(_status), ex=600)
    await redis.aclose()

    elapsed = (datetime.now(timezone.utc) - cycle_start).total_seconds()
    logger.info("=== Cycle complete in %.1fs | insights=%d deliveries=%d ===",
                elapsed, len(insights), deliveries)

    return {
        "cycle":      _status["cycles_completed"],
        "elapsed_s":  elapsed,
        "insights":   len(insights),
        "deliveries": deliveries,
        "financial":  financial["health"],
        "defense":    defense_report.get("worst_severity", "none"),
        "advancement": adv_result,
    }


async def run_scheduler(interval_seconds: int = 3600) -> None:
    """Main loop — runs orchestration cycle every N seconds."""
    logger.info("Scheduler starting. Interval: %ds", interval_seconds)
    while True:
        try:
            await run_orchestration_cycle()
        except Exception as e:
            logger.exception("Orchestration cycle failed: %s", e)
        await asyncio.sleep(interval_seconds)


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    asyncio.run(run_scheduler())
