"""
self_advancement_core.py — Autonomous Self-Improvement for SYMBIOTE-OS v3.0
Monitors performance, identifies weaknesses, proposes patches, and opens PRs for human review.

DESIGN PRINCIPLE: The system NEVER auto-merges or auto-deploys its own code changes.
All improvements go through a GitHub Pull Request requiring human review and approval.
This is a hard architectural constraint, not a soft suggestion.
"""

import os
import subprocess
import logging
import json
import textwrap
from datetime import datetime, timezone
from dataclasses import dataclass
from typing import Optional

import requests

logger = logging.getLogger(__name__)

# ─── Config ───────────────────────────────────────────────────────────────────

GITHUB_TOKEN      = os.getenv("GITHUB_TOKEN", "")
GITHUB_REPO       = os.getenv("GITHUB_REPO", "org/symbiote-os")
GITHUB_BASE_BRANCH = os.getenv("GITHUB_BASE_BRANCH", "main")
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
PERF_LOG_PATH     = os.getenv("PERF_LOG_PATH", "/data/perf_log.jsonl")

GH_API = "https://api.github.com"
GH_HEADERS = {
    "Authorization": f"Bearer {GITHUB_TOKEN}",
    "Accept": "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
}


# ─── Data Models ─────────────────────────────────────────────────────────────

@dataclass
class PerformanceSnapshot:
    component:        str
    metric:           str
    value:            float
    threshold:        float
    is_degraded:      bool
    snapshot_at:      str = ""

    def __post_init__(self):
        if not self.snapshot_at:
            self.snapshot_at = datetime.now(timezone.utc).isoformat()


@dataclass
class ImprovementProposal:
    title:          str
    description:    str
    component:      str
    priority:       str             # "low" | "medium" | "high"
    patch_diff:     str             # unified diff or full file replacement
    rationale:      str
    proposed_at:    str = ""
    pr_url:         Optional[str] = None

    def __post_init__(self):
        if not self.proposed_at:
            self.proposed_at = datetime.now(timezone.utc).isoformat()


# ─── Performance Monitoring ───────────────────────────────────────────────────

PERFORMANCE_THRESHOLDS = {
    "sentiment_confidence":    {"min": 0.70, "metric": "mean"},
    "insight_quality":         {"min": 0.75, "metric": "mean"},
    "api_error_rate":          {"max": 0.05, "metric": "rate"},
    "validation_pass_rate":    {"min": 0.90, "metric": "rate"},
    "graph_query_latency_ms":  {"max": 200,  "metric": "p95"},
}


def record_metric(component: str, metric: str, value: float) -> None:
    """Appends a metric observation to the performance log."""
    record = {
        "component": component,
        "metric":    metric,
        "value":     value,
        "ts":        datetime.now(timezone.utc).isoformat(),
    }
    with open(PERF_LOG_PATH, "a") as f:
        f.write(json.dumps(record) + "\n")


def analyse_performance() -> list[PerformanceSnapshot]:
    """
    Reads the performance log and identifies components below threshold.
    Returns a list of degraded snapshots.
    """
    history: dict[str, list[float]] = {}
    try:
        with open(PERF_LOG_PATH) as f:
            for line in f:
                r = json.loads(line.strip())
                key = f"{r['component']}:{r['metric']}"
                history.setdefault(key, []).append(r["value"])
    except FileNotFoundError:
        return []

    snapshots = []
    for key, values in history.items():
        comp, metric = key.split(":", 1)
        spec = PERFORMANCE_THRESHOLDS.get(metric, {})
        if not spec:
            continue

        agg_val = (sum(values) / len(values))  # simple mean
        degraded = False
        threshold = 0.0

        if "min" in spec:
            threshold = spec["min"]
            degraded  = agg_val < threshold
        elif "max" in spec:
            threshold = spec["max"]
            degraded  = agg_val > threshold

        snapshots.append(PerformanceSnapshot(
            component=comp, metric=metric, value=round(agg_val, 4),
            threshold=threshold, is_degraded=degraded,
        ))

    return snapshots


# ─── Code Analysis ───────────────────────────────────────────────────────────

def analyse_code_quality(file_path: str) -> dict:
    """
    Runs static analysis on a Python file.
    Returns findings from radon (complexity) and pyflakes (errors).
    """
    findings = {"file": file_path, "complexity": [], "lint_issues": []}

    # Cyclomatic complexity via radon
    try:
        r = subprocess.run(
            ["python", "-m", "radon", "cc", "-s", "-a", file_path],
            capture_output=True, text=True, timeout=30
        )
        findings["complexity"] = r.stdout.strip().splitlines()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass

    # Lint via pyflakes
    try:
        r = subprocess.run(
            ["python", "-m", "pyflakes", file_path],
            capture_output=True, text=True, timeout=30
        )
        if r.stdout:
            findings["lint_issues"] = r.stdout.strip().splitlines()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass

    return findings


# ─── AI-Powered Improvement Proposal ─────────────────────────────────────────

def propose_improvement(snapshot: PerformanceSnapshot,
                         code_context: str = "") -> Optional[ImprovementProposal]:
    """
    Uses Claude API to generate a targeted improvement proposal for a
    degraded component. Returns a proposal or None if generation fails.
    """
    if not ANTHROPIC_API_KEY:
        logger.warning("ANTHROPIC_API_KEY not set — cannot generate proposals")
        return None

    prompt = textwrap.dedent(f"""
        You are a senior Python engineer reviewing a system performance issue.

        Component: {snapshot.component}
        Metric: {snapshot.metric}
        Current value: {snapshot.value}
        Required threshold: {snapshot.threshold}
        Is degraded: {snapshot.is_degraded}

        Code context (excerpt):
        {code_context[:3000] if code_context else "Not provided"}

        Write a concise improvement proposal with:
        1. Root cause hypothesis
        2. Specific code change (as a Python code block or unified diff)
        3. Expected impact on the metric

        Be concrete and conservative — prefer small, safe changes.
        Output as JSON: {{"title":"..","description":"..","patch_diff":"..","rationale":".."}}
    """)

    try:
        resp = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "Content-Type": "application/json",
            },
            json={
                "model": "claude-opus-4-5-20250514",
                "max_tokens": 1024,
                "messages": [{"role": "user", "content": prompt}],
            },
            timeout=60,
        )
        resp.raise_for_status()
        text = resp.json()["content"][0]["text"]
        # Strip potential markdown fences
        text = text.strip().removeprefix("```json").removesuffix("```").strip()
        data = json.loads(text)

        return ImprovementProposal(
            title       = data.get("title", f"Improve {snapshot.component}"),
            description = data.get("description", ""),
            component   = snapshot.component,
            priority    = "high" if snapshot.value < snapshot.threshold * 0.8 else "medium",
            patch_diff  = data.get("patch_diff", ""),
            rationale   = data.get("rationale", ""),
        )
    except Exception as e:
        logger.error("Proposal generation failed: %s", e)
        return None


# ─── GitHub PR Integration ────────────────────────────────────────────────────

def open_improvement_pr(proposal: ImprovementProposal) -> Optional[str]:
    """
    Creates a GitHub branch and opens a Pull Request with the proposed change.
    NEVER auto-merges. Returns the PR URL or None.

    Requires: GITHUB_TOKEN with repo write access, GITHUB_REPO set.
    """
    if not GITHUB_TOKEN or not GITHUB_REPO:
        logger.warning("GitHub not configured — PR not opened")
        return None

    ts         = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    branch_name = f"symbiote/auto-improve/{proposal.component.replace('_','-')}-{ts}"

    # Get base branch SHA
    try:
        r = requests.get(
            f"{GH_API}/repos/{GITHUB_REPO}/git/ref/heads/{GITHUB_BASE_BRANCH}",
            headers=GH_HEADERS, timeout=10,
        )
        r.raise_for_status()
        base_sha = r.json()["object"]["sha"]
    except requests.RequestException as e:
        logger.error("Failed to get base branch SHA: %s", e)
        return None

    # Create branch
    try:
        r = requests.post(
            f"{GH_API}/repos/{GITHUB_REPO}/git/refs",
            headers=GH_HEADERS, timeout=10,
            json={"ref": f"refs/heads/{branch_name}", "sha": base_sha},
        )
        r.raise_for_status()
    except requests.RequestException as e:
        logger.error("Failed to create branch: %s", e)
        return None

    # Create PR (no file commit here — proposal includes diff for human to apply)
    pr_body = textwrap.dedent(f"""
        ## Automated Improvement Proposal 🤖

        **Component:** `{proposal.component}`
        **Priority:** {proposal.priority.upper()}
        **Proposed:** {proposal.proposed_at}

        ### Description
        {proposal.description}

        ### Rationale
        {proposal.rationale}

        ### Proposed Change
        ```diff
        {proposal.patch_diff}
        ```

        ---
        > ⚠️ This PR was generated autonomously by SYMBIOTE-OS self-advancement core.
        > **Human review and approval is REQUIRED before merging.**
        > Do not enable auto-merge on this PR.
    """)

    try:
        r = requests.post(
            f"{GH_API}/repos/{GITHUB_REPO}/pulls",
            headers=GH_HEADERS, timeout=10,
            json={
                "title":  f"[AUTO] {proposal.title}",
                "body":   pr_body,
                "head":   branch_name,
                "base":   GITHUB_BASE_BRANCH,
                "draft":  True,   # Always draft — requires deliberate human promotion
            },
        )
        r.raise_for_status()
        pr_url = r.json().get("html_url", "")
        proposal.pr_url = pr_url
        logger.info("PR opened (draft): %s", pr_url)
        return pr_url
    except requests.RequestException as e:
        logger.error("Failed to open PR: %s", e)
        return None


# ─── Main advancement cycle ───────────────────────────────────────────────────

def run_advancement_cycle(codebase_dir: str = "/app") -> dict:
    """
    Full self-advancement cycle:
    1. Analyse performance metrics
    2. Find worst degraded component
    3. Analyse its code
    4. Generate improvement proposal via Claude
    5. Open a DRAFT PR for human review
    Returns a summary dict.
    """
    snapshots = analyse_performance()
    degraded  = [s for s in snapshots if s.is_degraded]

    if not degraded:
        return {"status": "healthy", "proposals": 0, "message": "No degraded components"}

    # Focus on worst performer
    worst = min(degraded, key=lambda s: (
        (s.value / s.threshold) if s.threshold > 0 else 1.0
    ))

    # Load code context
    candidate_files = [
        os.path.join(codebase_dir, f)
        for f in os.listdir(codebase_dir)
        if f.endswith(".py") and worst.component.replace("_", "") in f.replace("_", "")
    ]
    code_context = ""
    for fp in candidate_files[:1]:
        try:
            with open(fp) as f:
                code_context = f.read()
        except OSError:
            pass

    analysis  = analyse_code_quality(candidate_files[0]) if candidate_files else {}
    proposal  = propose_improvement(worst, code_context)

    if proposal:
        pr_url = open_improvement_pr(proposal)
        return {
            "status":      "proposal_submitted",
            "component":   worst.component,
            "metric":      worst.metric,
            "current":     worst.value,
            "threshold":   worst.threshold,
            "pr_url":      pr_url,
            "proposal":    proposal.title,
        }

    return {
        "status":    "no_proposal",
        "component": worst.component,
        "analysis":  analysis,
    }
