"""
flask_app.py — Public-Facing REST API & Webhook Receiver for SYMBIOTE-OS v3.0
Handles client-facing endpoints, Stripe webhooks, admin operations, and status checks.
"""

import os
import json
import logging
from functools import wraps
from datetime import datetime, timezone

import redis
from flask import Flask, request, jsonify, g, send_file

from monetization_core import (
    create_stripe_products_and_prices,
    generate_checkout_link,
    process_webhook,
    get_wallet_balance,
    get_revenue_summary,
    approve_bill_payment,
)
from client_management_core import (
    init_db_schema,
    create_client,
    get_client_by_api_key,
    list_active_clients,
    grant_access,
    revoke_access,
    get_client_usage_stats,
    generate_automated_report,
    rotate_api_key,
    log_api_call,
)
from knowledge_graph_service import (
    init_constraints,
    get_high_confidence_insights,
    get_entity_risk_profile,
    search_entities,
    get_graph_stats,
)

# ─── App Setup ────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.config["JSON_SORT_KEYS"] = False

REDIS_URL      = os.getenv("REDIS_URL", "redis://redis:6379/0")
ADMIN_API_KEY  = os.getenv("ADMIN_API_KEY", "")  # Required for /admin/* endpoints

_redis: redis.Redis = redis.from_url(REDIS_URL, decode_responses=True)


# ─── Startup ──────────────────────────────────────────────────────────────────

def startup_init() -> None:
    logger.info("Initialising services...")
    try:
        init_db_schema()
        logger.info("PostgreSQL schema ready.")
    except Exception as e:
        logger.error("DB init failed: %s", e)

    try:
        init_constraints()
        logger.info("Neo4j constraints ready.")
    except Exception as e:
        logger.error("Neo4j init failed: %s", e)

    try:
        products = create_stripe_products_and_prices()
        logger.info("Stripe products: %s", list(products.keys()))
    except Exception as e:
        logger.error("Stripe init failed: %s", e)

    logger.info("Flask API ready.")


# Run startup when the module is loaded (covers both direct run and gunicorn workers)
with app.app_context():
    startup_init()


# ─── Auth Decorators ──────────────────────────────────────────────────────────

def require_api_key(f):
    """Validates Bearer token against client API keys in PostgreSQL."""
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            return jsonify({"error": "Missing API key"}), 401
        key    = auth.removeprefix("Bearer ").strip()
        client = get_client_by_api_key(key)
        if not client:
            return jsonify({"error": "Invalid or inactive API key"}), 403
        g.client    = client
        g.client_id = str(client["id"])
        response = f(*args, **kwargs)
        # Log usage with the actual response status code
        status_code = response[1] if isinstance(response, tuple) else 200
        log_api_call(
            client_id   = g.client_id,
            endpoint    = request.path,
            method      = request.method,
            ip_address  = request.remote_addr or "",
            status_code = status_code,
        )
        return response
    return decorated


def require_admin(f):
    """Validates admin API key from header."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if not ADMIN_API_KEY:
            return jsonify({"error": "Admin not configured"}), 503
        key = request.headers.get("X-Admin-Key", "")
        if key != ADMIN_API_KEY:
            return jsonify({"error": "Forbidden"}), 403
        return f(*args, **kwargs)
    return decorated


def check_usage_limit(f):
    """Rate-limits clients by plan tier."""
    @wraps(f)
    def decorated(*args, **kwargs):
        stats = get_client_usage_stats(g.client_id)
        if not stats.get("within_limit", True):
            return jsonify({
                "error": "Plan limit reached",
                "calls_this_month": stats.get("calls_this_month"),
                "limit": stats.get("limit"),
                "upgrade_url": "/checkout/professional",
            }), 429
        return f(*args, **kwargs)
    return decorated


# ─── Public Endpoints ─────────────────────────────────────────────────────────

@app.route("/health", methods=["GET"])
def health():
    """Public health check."""
    try:
        _redis.ping()
        redis_ok = True
    except Exception:
        redis_ok = False
    return jsonify({
        "status": "ok" if redis_ok else "degraded",
        "redis":  redis_ok,
        "ts":     datetime.now(timezone.utc).isoformat(),
    })


@app.route("/status", methods=["GET"])
def status():
    """Orchestrator status (public, redacted)."""
    raw = _redis.get("orchestrator:status")
    if not raw:
        return jsonify({"status": "initialising"}), 202
    data = json.loads(raw)
    # Redact sensitive financial details for public endpoint
    data.pop("financial", None)
    return jsonify(data)


# ─── Checkout / Subscriptions ─────────────────────────────────────────────────

@app.route("/register", methods=["POST"])
def register():
    """
    Public endpoint: creates a new client and returns their API key.
    The key is inactive until payment is confirmed.
    """
    body = request.get_json(silent=True) or {}
    email = body.get("email", "").strip().lower()
    name  = body.get("name", "").strip()
    if not email or not name:
        return jsonify({"error": "email and name required"}), 400

    try:
        client = create_client(email=email, name=name)
        return jsonify({
            "client_id": str(client["id"]),
            "api_key":   client["api_key"],
            "message":   "Account created. Subscribe to activate your key.",
            "plans":     "/plans",
        }), 201
    except Exception as e:
        logger.error("Registration error: %s", e)
        return jsonify({"error": "Registration failed"}), 500


@app.route("/plans", methods=["GET"])
def list_plans():
    """Returns available subscription plans with checkout links."""
    products = create_stripe_products_and_prices()
    client_id = request.args.get("client_id", "")
    plans = []
    for tier, info in products.items():
        checkout_url = ""
        if client_id:
            checkout_url = generate_checkout_link(info["price_id"], client_id) or ""
        plans.append({
            "tier":          tier,
            "price_usd":     info["unit_amount"] / 100,
            "billing":       "monthly",
            "checkout_url":  checkout_url,
        })
    return jsonify({"plans": plans})


@app.route("/checkout/<tier>", methods=["GET"])
def checkout(tier: str):
    """Generates a Stripe Checkout URL for a given tier + client."""
    client_id = request.args.get("client_id", "")
    if not client_id:
        return jsonify({"error": "client_id required"}), 400
    products = create_stripe_products_and_prices()
    product  = products.get(tier)
    if not product:
        return jsonify({"error": f"Unknown tier: {tier}"}), 404
    url = generate_checkout_link(product["price_id"], client_id)
    if not url:
        return jsonify({"error": "Checkout session creation failed"}), 500
    return jsonify({"checkout_url": url, "tier": tier})


# ─── Stripe Webhook ───────────────────────────────────────────────────────────

@app.route("/webhooks/stripe", methods=["POST"])
def stripe_webhook():
    """
    Stripe webhook receiver. Processes payment events and updates
    client access accordingly.
    """
    payload    = request.get_data()
    sig_header = request.headers.get("Stripe-Signature", "")

    result = process_webhook(payload, sig_header)

    if result["action"] == "rejected":
        return jsonify({"error": "Invalid signature"}), 400

    client_id = result.get("client_id")
    action    = result.get("action")

    if action == "payment_succeeded" and client_id:
        # Determine tier from subscription data
        tier = result.get("data", {}).get("tier", "starter")
        grant_access(client_id, tier)

    elif action == "checkout_completed" and client_id:
        grant_access(client_id, "starter")  # upgrade after price_id lookup

    elif action == "subscription_canceled" and client_id:
        revoke_access(client_id)

    elif action == "payment_failed" and client_id:
        logger.warning("Payment failed for client %s", client_id)

    return jsonify({"received": True, "action": action}), 200


# ─── Intelligence API (authenticated) ────────────────────────────────────────

@app.route("/api/insights", methods=["GET"])
@require_api_key
@check_usage_limit
def get_insights():
    """Returns high-confidence insights from the knowledge graph."""
    min_conf = float(request.args.get("min_confidence", "0.75"))
    limit    = min(int(request.args.get("limit", "20")), 100)
    insights = get_high_confidence_insights(min_confidence=min_conf, limit=limit)
    return jsonify({
        "insights": insights,
        "count":    len(insights),
        "client_tier": g.client.get("plan_tier"),
    })


@app.route("/api/entities/search", methods=["GET"])
@require_api_key
@check_usage_limit
def search_entity():
    """Full-text search over entity names in the knowledge graph."""
    q     = request.args.get("q", "")
    limit = min(int(request.args.get("limit", "10")), 50)
    if not q:
        return jsonify({"error": "query parameter 'q' required"}), 400
    results = search_entities(q, limit=limit)
    return jsonify({"results": results, "count": len(results)})


@app.route("/api/entities/<entity_id>/risk", methods=["GET"])
@require_api_key
@check_usage_limit
def entity_risk(entity_id: str):
    """Returns the risk profile for a specific entity."""
    profile = get_entity_risk_profile(entity_id)
    if not profile:
        return jsonify({"error": "Entity not found"}), 404
    return jsonify(profile)


@app.route("/api/usage", methods=["GET"])
@require_api_key
def usage():
    """Returns current API usage stats for the authenticated client."""
    return jsonify(get_client_usage_stats(g.client_id))


@app.route("/api/reports/latest", methods=["GET"])
@require_api_key
def latest_report():
    """
    Returns the path/metadata for the client's latest generated report.
    The report PDF can be fetched separately.
    """
    raw = _redis.lindex(f"reports:{g.client_id}", 0)
    if not raw:
        return jsonify({"message": "No reports yet — check back after the next cycle"}), 404
    return jsonify(json.loads(raw))


@app.route("/api/reports/download/<path:filename>", methods=["GET"])
@require_api_key
def download_report(filename: str):
    """Downloads a specific report PDF."""
    report_dir = os.getenv("REPORT_OUTPUT_DIR", "/data/reports")
    filepath   = os.path.join(report_dir, os.path.basename(filename))
    if not os.path.isfile(filepath):
        return jsonify({"error": "Report not found"}), 404
    return send_file(filepath, mimetype="application/pdf",
                     as_attachment=True, download_name=os.path.basename(filepath))


@app.route("/api/rotate-key", methods=["POST"])
@require_api_key
def api_rotate_key():
    """Issues a new API key for the authenticated client."""
    new_key = rotate_api_key(g.client_id)
    return jsonify({"new_api_key": new_key,
                    "message": "Previous key is now invalid."})


# ─── Admin Endpoints ──────────────────────────────────────────────────────────

@app.route("/admin/status", methods=["GET"])
@require_admin
def admin_status():
    """Full orchestrator status including financials (admin only)."""
    raw = _redis.get("orchestrator:status")
    return jsonify(json.loads(raw) if raw else {"status": "no_data"})


@app.route("/admin/financial", methods=["GET"])
@require_admin
def admin_financial():
    """Wallet balance and 30-day revenue summary."""
    return jsonify({
        "balance": get_wallet_balance(),
        "revenue": get_revenue_summary(days=30),
    })


@app.route("/admin/clients", methods=["GET"])
@require_admin
def admin_clients():
    """Lists all active clients."""
    tier = request.args.get("tier")
    return jsonify({"clients": list_active_clients(tier=tier)})


@app.route("/admin/clients/<client_id>/grant", methods=["POST"])
@require_admin
def admin_grant(client_id: str):
    """Manually grants access to a client."""
    body = request.get_json(silent=True) or {}
    tier = body.get("tier", "starter")
    ok   = grant_access(client_id, tier)
    return jsonify({"success": ok, "tier": tier})


@app.route("/admin/clients/<client_id>/revoke", methods=["POST"])
@require_admin
def admin_revoke(client_id: str):
    """Manually revokes a client's access."""
    ok = revoke_access(client_id)
    return jsonify({"success": ok})


@app.route("/admin/clients/<client_id>/report", methods=["POST"])
@require_admin
def admin_generate_report(client_id: str):
    """Manually triggers report generation for a client."""
    filepath = generate_automated_report(client_id, report_type="manual")
    if filepath:
        return jsonify({"success": True, "file": filepath})
    return jsonify({"success": False}), 500


@app.route("/admin/approve-payment/<int:payment_id>", methods=["POST"])
@require_admin
def admin_approve_payment(payment_id: int):
    """
    Human approval gate for autonomous bill payments above threshold.
    Requires both admin key (header) and approval token (body).
    """
    body  = request.get_json(silent=True) or {}
    token = body.get("approval_token", "")
    result = approve_bill_payment(payment_id, token)
    return jsonify(result)


@app.route("/admin/graph/stats", methods=["GET"])
@require_admin
def admin_graph_stats():
    return jsonify(get_graph_stats())


# ─── Error Handlers ───────────────────────────────────────────────────────────

@app.errorhandler(404)
def not_found(_):
    return jsonify({"error": "Not found"}), 404

@app.errorhandler(405)
def method_not_allowed(_):
    return jsonify({"error": "Method not allowed"}), 405

@app.errorhandler(500)
def internal_error(e):
    logger.exception("Internal server error")
    return jsonify({"error": "Internal server error"}), 500


# ─── Entry Point ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
