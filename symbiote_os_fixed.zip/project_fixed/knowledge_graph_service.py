"""
knowledge_graph_service.py — Neo4j Knowledge Graph Service for SYMBIOTE-OS v3.0
Manages entities, relationships, and graph-based intelligence queries.
"""

import os
import logging
from datetime import datetime, timezone
from typing import Optional

from neo4j import GraphDatabase, Driver
from neo4j.exceptions import Neo4jError

logger = logging.getLogger(__name__)

# ─── Config ───────────────────────────────────────────────────────────────────

NEO4J_URI      = os.getenv("NEO4J_URI", "bolt://neo4j:7687")
NEO4J_USER     = os.getenv("NEO4J_USER", "neo4j")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD", "symbiote_secret")

# ─── Driver Singleton ─────────────────────────────────────────────────────────

_driver: Optional[Driver] = None

def get_driver() -> Driver:
    global _driver
    if _driver is None:
        _driver = GraphDatabase.driver(
            NEO4J_URI,
            auth=(NEO4J_USER, NEO4J_PASSWORD),
            max_connection_lifetime=3600,
            max_connection_pool_size=50,
        )
    return _driver


def close_driver() -> None:
    global _driver
    if _driver:
        _driver.close()
        _driver = None


def init_constraints() -> None:
    """Creates uniqueness constraints and indices on first run."""
    with get_driver().session() as session:
        cmds = [
            "CREATE CONSTRAINT entity_id IF NOT EXISTS FOR (e:Entity) REQUIRE e.id IS UNIQUE",
            "CREATE CONSTRAINT event_id  IF NOT EXISTS FOR (v:Event)  REQUIRE v.id IS UNIQUE",
            "CREATE INDEX entity_name IF NOT EXISTS FOR (e:Entity) ON (e.name)",
            "CREATE INDEX event_date  IF NOT EXISTS FOR (v:Event)  ON (v.date)",
        ]
        for cmd in cmds:
            try:
                session.run(cmd)
            except Neo4jError as e:
                logger.debug("Constraint/index already exists or failed: %s", e)
    logger.info("Neo4j constraints and indices initialised.")

# ─── Entity Management ────────────────────────────────────────────────────────

def upsert_entity(entity_id: str, entity_type: str, name: str,
                  properties: Optional[dict] = None) -> bool:
    """
    Creates or updates an entity node.
    entity_type: "Country", "Organization", "Person", "Commodity", "Technology", etc.
    """
    props = properties or {}
    props.update({"id": entity_id, "name": name,
                  "updated_at": datetime.now(timezone.utc).isoformat()})
    query = f"""
        MERGE (e:Entity:{entity_type} {{id: $id}})
        SET e += $props
        RETURN e.id AS id
    """
    with get_driver().session() as session:
        try:
            result = session.run(query, id=entity_id, props=props)
            return result.single() is not None
        except Neo4jError as e:
            logger.error("upsert_entity failed: %s", e)
            return False


def upsert_event(event_id: str, event_type: str, title: str,
                 date: str, confidence: float,
                 properties: Optional[dict] = None) -> bool:
    """Creates or updates an Event node."""
    props = properties or {}
    props.update({
        "id": event_id, "type": event_type, "title": title,
        "date": date, "confidence": confidence,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    })
    query = """
        MERGE (v:Event {id: $id})
        SET v += $props
        RETURN v.id AS id
    """
    with get_driver().session() as session:
        try:
            result = session.run(query, id=event_id, props=props)
            return result.single() is not None
        except Neo4jError as e:
            logger.error("upsert_event failed: %s", e)
            return False


def link_entity_to_event(entity_id: str, event_id: str,
                          relationship: str = "INVOLVED_IN",
                          properties: Optional[dict] = None) -> bool:
    """Creates a directed relationship between an Entity and an Event."""
    props = properties or {}
    query = f"""
        MATCH (e:Entity {{id: $eid}})
        MATCH (v:Event  {{id: $vid}})
        MERGE (e)-[r:{relationship}]->(v)
        SET r += $props
        RETURN r
    """
    with get_driver().session() as session:
        try:
            result = session.run(query, eid=entity_id, vid=event_id, props=props)
            return result.single() is not None
        except Neo4jError as e:
            logger.error("link_entity_to_event failed: %s", e)
            return False


def link_entities(source_id: str, target_id: str, relationship: str,
                  properties: Optional[dict] = None) -> bool:
    """Creates a directed relationship between two entities."""
    props = properties or {}
    query = f"""
        MATCH (s:Entity {{id: $sid}})
        MATCH (t:Entity {{id: $tid}})
        MERGE (s)-[r:{relationship}]->(t)
        SET r += $props
        RETURN r
    """
    with get_driver().session() as session:
        try:
            result = session.run(query, sid=source_id, tid=target_id, props=props)
            return result.single() is not None
        except Neo4jError as e:
            logger.error("link_entities failed: %s", e)
            return False

# ─── Intelligence Queries ──────────────────────────────────────────────────────

def get_high_confidence_insights(min_confidence: float = 0.75,
                                  limit: int = 20) -> list[dict]:
    """
    Returns recent high-confidence events with their associated entities.
    """
    query = """
        MATCH (v:Event)
        WHERE v.confidence >= $min_conf
        OPTIONAL MATCH (e:Entity)-[:INVOLVED_IN]->(v)
        WITH v, collect(e.name) AS actors
        ORDER BY v.date DESC, v.confidence DESC
        LIMIT $limit
        RETURN v.id AS id, v.title AS title, v.type AS type,
               v.date AS date, v.confidence AS confidence,
               v.summary AS summary, actors
    """
    with get_driver().session() as session:
        try:
            result = session.run(query, min_conf=min_confidence, limit=limit)
            return [dict(r) for r in result]
        except Neo4jError as e:
            logger.error("get_high_confidence_insights failed: %s", e)
            return []


def get_entity_risk_profile(entity_id: str) -> dict:
    """
    Returns a risk profile for an entity: degree centrality, linked events,
    associated entities (2-hop), and average event confidence.
    """
    query = """
        MATCH (e:Entity {id: $eid})
        OPTIONAL MATCH (e)-[*1..2]-(n:Entity)
        WITH e, collect(DISTINCT n.name) AS neighbors
        OPTIONAL MATCH (e)-[:INVOLVED_IN]->(v:Event)
        WITH e, neighbors, collect(v) AS events
        RETURN e.id AS id, e.name AS name,
               size(neighbors) AS network_degree,
               size(events)    AS event_count,
               [ev IN events | ev.confidence] AS confidences,
               [ev IN events | ev.title][..5] AS recent_events
    """
    with get_driver().session() as session:
        try:
            result = session.run(query, eid=entity_id)
            row    = result.single()
            if not row:
                return {}
            d = dict(row)
            confs = d.pop("confidences", []) or []
            d["avg_confidence"] = (sum(confs) / len(confs)) if confs else 0.0
            return d
        except Neo4jError as e:
            logger.error("get_entity_risk_profile failed: %s", e)
            return {}


def get_shortest_path(source_id: str, target_id: str,
                       max_hops: int = 4) -> Optional[list]:
    """Returns the shortest relationship path between two entities."""
    query = """
        MATCH path = shortestPath(
            (s:Entity {id: $sid})-[*1..$hops]-(t:Entity {id: $tid})
        )
        RETURN [n IN nodes(path) | n.name] AS node_names,
               [r IN relationships(path) | type(r)] AS rel_types
        LIMIT 1
    """
    with get_driver().session() as session:
        try:
            result = session.run(query, sid=source_id, tid=target_id, hops=max_hops)
            row    = result.single()
            if not row:
                return None
            names  = row["node_names"]
            rels   = row["rel_types"]
            path   = [names[0]]
            for rel, node in zip(rels, names[1:]):
                path.extend([f"—[{rel}]→", node])
            return path
        except Neo4jError as e:
            logger.error("get_shortest_path failed: %s", e)
            return None


def get_graph_stats() -> dict:
    """Returns aggregate counts of nodes and relationships."""
    with get_driver().session() as session:
        try:
            counts = {}
            for label in ("Entity", "Event"):
                r = session.run(f"MATCH (n:{label}) RETURN count(n) AS c")
                counts[label.lower() + "_count"] = r.single()["c"]
            r = session.run("MATCH ()-[r]->() RETURN count(r) AS c")
            counts["relationship_count"] = r.single()["c"]
            return counts
        except Neo4jError as e:
            logger.error("get_graph_stats failed: %s", e)
            return {}


def search_entities(query_text: str, limit: int = 10) -> list[dict]:
    """Full-text style search over entity names."""
    query = """
        MATCH (e:Entity)
        WHERE toLower(e.name) CONTAINS toLower($q)
        RETURN e.id AS id, e.name AS name, labels(e) AS labels
        LIMIT $limit
    """
    with get_driver().session() as session:
        try:
            result = session.run(query, q=query_text, limit=limit)
            return [dict(r) for r in result]
        except Neo4jError as e:
            logger.error("search_entities failed: %s", e)
            return []
